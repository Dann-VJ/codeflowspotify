"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/callback";
exports.ids = ["pages/api/callback"];
exports.modules = {

/***/ "node:querystring":
/*!***********************************!*\
  !*** external "node:querystring" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("node:querystring");

/***/ }),

/***/ "(api)/./pages/api/callback.js":
/*!*******************************!*\
  !*** ./pages/api/callback.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var node_querystring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! node:querystring */ \"node:querystring\");\n/* harmony import */ var node_querystring__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(node_querystring__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _utils_encode__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/encode */ \"(api)/./utils/encode.js\");\n\n\nconst SPOTIFY_TOKEN_URL = \"https://accounts.spotify.com/api/token\";\nasync function handler(req, res) {\n    const clientAuth = (0,_utils_encode__WEBPACK_IMPORTED_MODULE_1__.encode)(`${process.env.SPOTIFY_CLIENT_ID}:${process.env.SECRET}`);\n    const options = {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/x-www-form-urlencoded\",\n            Authorization: `Basic ${clientAuth}`\n        },\n        body: node_querystring__WEBPACK_IMPORTED_MODULE_0___default().stringify({\n            code: req.query.code,\n            redirect_uri: process.env.REDIRECT_URI,\n            grant_type: \"authorization_code\"\n        })\n    };\n    try {\n        const response = await fetch(SPOTIFY_TOKEN_URL, options);\n        const data = await response.json();\n        res.setHeader(\"Set-Cookie\", `access_token=${data.access_token}; Path=/; HttpOnly`);\n        res.writeHead(302, {\n            Location: \"/home\"\n        });\n        res.end();\n    } catch (error) {\n        console.error(error);\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvY2FsbGJhY2suanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUEyQztBQUNGO0FBRXpDLE1BQU1FLG9CQUFvQjtBQUVYLGVBQWVDLFFBQVFDLEdBQUcsRUFBRUMsR0FBRyxFQUFFO0lBQzlDLE1BQU1DLGFBQWFMLHFEQUFNQSxDQUFDLENBQUMsRUFBRU0sUUFBUUMsR0FBRyxDQUFDQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUVGLFFBQVFDLEdBQUcsQ0FBQ0UsTUFBTSxDQUFDLENBQUM7SUFDbEYsTUFBTUMsVUFBVTtRQUNkQyxRQUFRO1FBQ1JDLFNBQVM7WUFDUCxnQkFBZ0I7WUFDaEJDLGVBQWUsQ0FBQyxNQUFNLEVBQUVSLFdBQVcsQ0FBQztRQUN0QztRQUNBUyxNQUFNZixpRUFBcUIsQ0FBQztZQUMxQmlCLE1BQU1iLElBQUljLEtBQUssQ0FBQ0QsSUFBSTtZQUNwQkUsY0FBY1osUUFBUUMsR0FBRyxDQUFDWSxZQUFZO1lBQ3RDQyxZQUFZO1FBQ2Q7SUFDRjtJQUVBLElBQUk7UUFDRixNQUFNQyxXQUFXLE1BQU1DLE1BQU1yQixtQkFBbUJTO1FBQ2hELE1BQU1hLE9BQU8sTUFBTUYsU0FBU0csSUFBSTtRQUVoQ3BCLElBQUlxQixTQUFTLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFBRUYsS0FBS0csWUFBWSxDQUFDLGtCQUFrQixDQUFDO1FBRWpGdEIsSUFBSXVCLFNBQVMsQ0FBQyxLQUFLO1lBQUVDLFVBQVU7UUFBUTtRQUN2Q3hCLElBQUl5QixHQUFHO0lBQ1QsRUFBRSxPQUFPQyxPQUFPO1FBQ2RDLFFBQVFELEtBQUssQ0FBQ0E7SUFDaEI7QUFDRixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXV0aC1jb2RlLWZsb3cvLi9wYWdlcy9hcGkvY2FsbGJhY2suanM/NzZlZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgcXVlcnlzdHJpbmcgZnJvbSBcIm5vZGU6cXVlcnlzdHJpbmdcIjtcclxuaW1wb3J0IHtlbmNvZGV9IGZyb20gXCIuLi8uLi91dGlscy9lbmNvZGVcIlxyXG5cclxuY29uc3QgU1BPVElGWV9UT0tFTl9VUkwgPSBcImh0dHBzOi8vYWNjb3VudHMuc3BvdGlmeS5jb20vYXBpL3Rva2VuXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgY29uc3QgY2xpZW50QXV0aCA9IGVuY29kZShgJHtwcm9jZXNzLmVudi5TUE9USUZZX0NMSUVOVF9JRH06JHtwcm9jZXNzLmVudi5TRUNSRVR9YClcclxuICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgIGhlYWRlcnM6IHtcclxuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIixcclxuICAgICAgQXV0aG9yaXphdGlvbjogYEJhc2ljICR7Y2xpZW50QXV0aH1gLFxyXG4gICAgfSxcclxuICAgIGJvZHk6IHF1ZXJ5c3RyaW5nLnN0cmluZ2lmeSh7XHJcbiAgICAgIGNvZGU6IHJlcS5xdWVyeS5jb2RlLFxyXG4gICAgICByZWRpcmVjdF91cmk6IHByb2Nlc3MuZW52LlJFRElSRUNUX1VSSSxcclxuICAgICAgZ3JhbnRfdHlwZTogXCJhdXRob3JpemF0aW9uX2NvZGVcIixcclxuICAgIH0pXHJcbiAgfTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goU1BPVElGWV9UT0tFTl9VUkwsIG9wdGlvbnMpO1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuXHJcbiAgICByZXMuc2V0SGVhZGVyKFwiU2V0LUNvb2tpZVwiLCBgYWNjZXNzX3Rva2VuPSR7ZGF0YS5hY2Nlc3NfdG9rZW59OyBQYXRoPS87IEh0dHBPbmx5YCk7XHJcblxyXG4gICAgcmVzLndyaXRlSGVhZCgzMDIsIHsgTG9jYXRpb246IFwiL2hvbWVcIiB9KTtcclxuICAgIHJlcy5lbmQoKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJxdWVyeXN0cmluZyIsImVuY29kZSIsIlNQT1RJRllfVE9LRU5fVVJMIiwiaGFuZGxlciIsInJlcSIsInJlcyIsImNsaWVudEF1dGgiLCJwcm9jZXNzIiwiZW52IiwiU1BPVElGWV9DTElFTlRfSUQiLCJTRUNSRVQiLCJvcHRpb25zIiwibWV0aG9kIiwiaGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJib2R5Iiwic3RyaW5naWZ5IiwiY29kZSIsInF1ZXJ5IiwicmVkaXJlY3RfdXJpIiwiUkVESVJFQ1RfVVJJIiwiZ3JhbnRfdHlwZSIsInJlc3BvbnNlIiwiZmV0Y2giLCJkYXRhIiwianNvbiIsInNldEhlYWRlciIsImFjY2Vzc190b2tlbiIsIndyaXRlSGVhZCIsIkxvY2F0aW9uIiwiZW5kIiwiZXJyb3IiLCJjb25zb2xlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/callback.js\n");

/***/ }),

/***/ "(api)/./utils/encode.js":
/*!*************************!*\
  !*** ./utils/encode.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"encode\": () => (/* binding */ encode)\n/* harmony export */ });\nconst encode = (str)=>Buffer.from(str).toString(\"base64url\");\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9lbmNvZGUuanMuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUFPLE1BQU1BLFNBQVMsQ0FBQ0MsTUFBUUMsT0FBT0MsSUFBSSxDQUFDRixLQUFLRyxRQUFRLENBQUMsYUFBYSIsInNvdXJjZXMiOlsid2VicGFjazovL2F1dGgtY29kZS1mbG93Ly4vdXRpbHMvZW5jb2RlLmpzP2U2YzIiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGVuY29kZSA9IChzdHIpID0+IEJ1ZmZlci5mcm9tKHN0cikudG9TdHJpbmcoXCJiYXNlNjR1cmxcIik7XHJcbiJdLCJuYW1lcyI6WyJlbmNvZGUiLCJzdHIiLCJCdWZmZXIiLCJmcm9tIiwidG9TdHJpbmciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./utils/encode.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/callback.js"));
module.exports = __webpack_exports__;

})();