"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/login";
exports.ids = ["pages/api/login"];
exports.modules = {

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ "(api)/./pages/api/login.js":
/*!****************************!*\
  !*** ./pages/api/login.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\nconst SPOTIFY_AUTH_URL = \"https://accounts.spotify.com/authorize\";\nfunction handler(req, res) {\n    const scopes = [\n        \"user-read-private\",\n        \"user-read-email\",\n        \"playlist-read-private\"\n    ];\n    //const query = \"\";\n    const querystring = __webpack_require__(/*! querystring */ \"querystring\");\n    const query = querystring.stringify({\n        response_type: \"code\",\n        client_id: process.env.SPOTIFY_CLIENT_ID,\n        scope: scopes.join(\" \"),\n        redirect_uri: process.env.REDIRECT_URI\n    });\n    res.writeHead(302, {\n        Location: `${SPOTIFY_AUTH_URL}?${query}`\n    });\n    res.end();\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvbG9naW4uanMuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE1BQU1BLG1CQUFtQjtBQUVWLFNBQVNDLFFBQVFDLEdBQUcsRUFBRUMsR0FBRyxFQUFFO0lBQ3hDLE1BQU1DLFNBQVM7UUFDYjtRQUNBO1FBQ0E7S0FDRDtJQUVELG1CQUFtQjtJQUNuQixNQUFNQyxjQUFjQyxtQkFBT0EsQ0FBQztJQUU1QixNQUFNQyxRQUFRRixZQUFZRyxTQUFTLENBQUM7UUFDbENDLGVBQWU7UUFDZkMsV0FBV0MsUUFBUUMsR0FBRyxDQUFDQyxpQkFBaUI7UUFDeENDLE9BQU9WLE9BQU9XLElBQUksQ0FBQztRQUNuQkMsY0FBY0wsUUFBUUMsR0FBRyxDQUFDSyxZQUFZO0lBQ3hDO0lBRUFkLElBQUllLFNBQVMsQ0FBQyxLQUFLO1FBQUVDLFVBQVUsQ0FBQyxFQUFFbkIsaUJBQWlCLENBQUMsRUFBRU8sTUFBTSxDQUFDO0lBQUM7SUFDOURKLElBQUlpQixHQUFHO0FBQ1QsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2F1dGgtY29kZS1mbG93Ly4vcGFnZXMvYXBpL2xvZ2luLmpzP2FlODgiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgU1BPVElGWV9BVVRIX1VSTCA9IFwiaHR0cHM6Ly9hY2NvdW50cy5zcG90aWZ5LmNvbS9hdXRob3JpemVcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICBjb25zdCBzY29wZXMgPSBbXHJcbiAgICBcInVzZXItcmVhZC1wcml2YXRlXCIsXHJcbiAgICBcInVzZXItcmVhZC1lbWFpbFwiLFxyXG4gICAgXCJwbGF5bGlzdC1yZWFkLXByaXZhdGVcIixcclxuICBdO1xyXG5cclxuICAvL2NvbnN0IHF1ZXJ5ID0gXCJcIjtcclxuICBjb25zdCBxdWVyeXN0cmluZyA9IHJlcXVpcmUoJ3F1ZXJ5c3RyaW5nJyk7XHJcblxyXG4gIGNvbnN0IHF1ZXJ5ID0gcXVlcnlzdHJpbmcuc3RyaW5naWZ5KHtcclxuICAgIHJlc3BvbnNlX3R5cGU6IFwiY29kZVwiLFxyXG4gICAgY2xpZW50X2lkOiBwcm9jZXNzLmVudi5TUE9USUZZX0NMSUVOVF9JRCxcclxuICAgIHNjb3BlOiBzY29wZXMuam9pbihcIiBcIiksXHJcbiAgICByZWRpcmVjdF91cmk6IHByb2Nlc3MuZW52LlJFRElSRUNUX1VSSSxcclxuICB9KTtcclxuXHJcbiAgcmVzLndyaXRlSGVhZCgzMDIsIHsgTG9jYXRpb246IGAke1NQT1RJRllfQVVUSF9VUkx9PyR7cXVlcnl9YCB9KTtcclxuICByZXMuZW5kKCk7XHJcbn1cclxuIl0sIm5hbWVzIjpbIlNQT1RJRllfQVVUSF9VUkwiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwic2NvcGVzIiwicXVlcnlzdHJpbmciLCJyZXF1aXJlIiwicXVlcnkiLCJzdHJpbmdpZnkiLCJyZXNwb25zZV90eXBlIiwiY2xpZW50X2lkIiwicHJvY2VzcyIsImVudiIsIlNQT1RJRllfQ0xJRU5UX0lEIiwic2NvcGUiLCJqb2luIiwicmVkaXJlY3RfdXJpIiwiUkVESVJFQ1RfVVJJIiwid3JpdGVIZWFkIiwiTG9jYXRpb24iLCJlbmQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/login.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/login.js"));
module.exports = __webpack_exports__;

})();