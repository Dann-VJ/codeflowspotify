export const MainContainer = ({ children }) => {
  return (
    <main className="flex items-center h-screen bg-slate-200">{children}</main>
  );
};
