export const encode = (str) => Buffer.from(str).toString("base64url");
